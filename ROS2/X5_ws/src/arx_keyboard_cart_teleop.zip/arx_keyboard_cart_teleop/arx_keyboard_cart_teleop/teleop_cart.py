#!/usr/bin/env python3
import sys
import time
import select
import termios
import tty

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy

from arx5_arm_msg.msg import RobotCmd, RobotStatus


class CartTeleop(Node):
    # Soft joint limits (rad)
    JOINT_LIMITS = [
        (-1.57,  1.57),  # J1
        (-0.10,  3.60),  # J2
        (-0.10,  3.00),  # J3
        (-1.29,  1.29),  # J4
        (-1.48,  1.48),  # J5
        (-1.74,  1.74),  # J6
    ]
    LIMIT_MARGIN = 0.06  # rad

    def __init__(self):
        super().__init__("arx_keyboard_cart_teleop")

        qos = QoSProfile(depth=10)
        qos.reliability = ReliabilityPolicy.RELIABLE
        qos.durability = DurabilityPolicy.VOLATILE

        self.pub = self.create_publisher(RobotCmd, "/arm_cmd", qos)
        self.sub = self.create_subscription(RobotStatus, "/arm_status", self.on_status, qos)

        self.have_state = False
        self.end_pos_fb = [0.0] * 6
        self.cmd_pos = [0.0] * 6
        self.joint_pos = [0.0] * 7
        self.gripper_hold = 0.0

        self.dt = 0.02  # 50Hz
        self.timer = self.create_timer(self.dt, self.on_timer)

        # VERY slow defaults (safe)
        self.v_lin_max = 0.003  # m/s
        self.v_ang_max = 0.05   # rad/s
        self.a_lin_max = 0.02   # m/s^2
        self.a_ang_max = 0.30   # rad/s^2

        self.lin_scale = 1.0
        self.ang_scale = 1.0

        self.v = [0.0] * 6
        self.v_target = [0.0] * 6

        self.last_input_t = time.time()
        self.input_timeout = 0.2
        self.last_warn_t = 0.0

        # raw terminal mode
        self.old_term = termios.tcgetattr(sys.stdin)
        tty.setcbreak(sys.stdin.fileno())

        self.get_logger().info(
            "ARX X5 Cartesian teleop (/arm_cmd mode=4)\n"
            "Deadman: use UPPERCASE keys (Shift+W etc). Release -> stop.\n"
            "Move: W/S(+/-X) A/D(+/-Y) R/F(+/-Z)\n"
            "Rot : I/K(+/-Roll) J/L(+/-Pitch) U/O(+/-Yaw)\n"
            "Speed: Z/X lin-/lin+  C/V ang-/ang+\n"
            "H: resync, ESC: stop\n"
            "Do NOT run other /arm_cmd publishers at the same time."
        )

    def destroy_node(self):
        try:
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.old_term)
        except Exception:
            pass
        super().destroy_node()

    def on_status(self, msg: RobotStatus):
        self.end_pos_fb = list(msg.end_pos)
        self.joint_pos = list(msg.joint_pos)
        if len(self.joint_pos) >= 7:
            self.gripper_hold = float(self.joint_pos[6])

        if not self.have_state:
            self.cmd_pos = self.end_pos_fb.copy()
            self.have_state = True
            self.get_logger().info(f"Synced end_pos={self.cmd_pos}, gripper_hold={self.gripper_hold:.4f}")

    def read_key(self):
        dr, _, _ = select.select([sys.stdin], [], [], 0.0)
        if dr:
            return sys.stdin.read(1)
        return None

    def near_joint_limit(self):
        for j in range(6):
            lo, hi = self.JOINT_LIMITS[j]
            q = float(self.joint_pos[j])
            if q < lo + self.LIMIT_MARGIN or q > hi - self.LIMIT_MARGIN:
                return True, j, q, lo, hi
        return False, -1, 0.0, 0.0, 0.0

    def accel_limit(self, cur, tgt, amax):
        step = amax * self.dt
        if tgt > cur + step:
            return cur + step
        if tgt < cur - step:
            return cur - step
        return tgt

    def on_timer(self):
        if not self.have_state:
            return

        now = time.time()
        k = self.read_key()

        self.v_target = [0.0] * 6

        if k is not None:
            self.last_input_t = now

            if k == "\x1b":  # ESC
                self.v = [0.0] * 6
                self.v_target = [0.0] * 6

            elif k in ("h", "H"):
                self.cmd_pos = self.end_pos_fb.copy()

            elif k in ("z", "Z"):
                self.lin_scale = max(0.1, self.lin_scale / 1.25)
                self.get_logger().info(f"lin_scale={self.lin_scale:.3f}")
            elif k in ("x", "X"):
                self.lin_scale = min(5.0, self.lin_scale * 1.25)
                self.get_logger().info(f"lin_scale={self.lin_scale:.3f}")
            elif k in ("c", "C"):
                self.ang_scale = max(0.1, self.ang_scale / 1.25)
                self.get_logger().info(f"ang_scale={self.ang_scale:.3f}")
            elif k in ("v", "V"):
                self.ang_scale = min(5.0, self.ang_scale * 1.25)
                self.get_logger().info(f"ang_scale={self.ang_scale:.3f}")

            else:
                lin = self.v_lin_max * self.lin_scale
                ang = self.v_ang_max * self.ang_scale
                mapping = {
                    "W": (0, +lin), "S": (0, -lin),
                    "A": (1, +lin), "D": (1, -lin),
                    "R": (2, +lin), "F": (2, -lin),
                    "I": (3, +ang), "K": (3, -ang),
                    "J": (4, +ang), "L": (4, -ang),
                    "U": (5, +ang), "O": (5, -ang),
                }
                if k in mapping:
                    idx, val = mapping[k]
                    self.v_target[idx] = val

        # watchdog
        if now - self.last_input_t > self.input_timeout:
            self.v_target = [0.0] * 6

        # joint limit stop
        hit, j, q, lo, hi = self.near_joint_limit()
        if hit:
            self.v_target = [0.0] * 6
            if now - self.last_warn_t > 1.0:
                self.last_warn_t = now
                self.get_logger().warn(f"Near joint limit: J{j+1}={q:.3f} in [{lo:.2f},{hi:.2f}] -> STOP")

        # accel limit
        for i in range(6):
            if i < 3:
                self.v[i] = self.accel_limit(self.v[i], self.v_target[i], self.a_lin_max)
            else:
                self.v[i] = self.accel_limit(self.v[i], self.v_target[i], self.a_ang_max)

        # integrate
        for i in range(6):
            self.cmd_pos[i] += self.v[i] * self.dt

        # publish
        cmd = RobotCmd()
        cmd.header.stamp = self.get_clock().now().to_msg()
        cmd.end_pos = [float(x) for x in self.cmd_pos]
        cmd.joint_pos = [0.0] * 6
        cmd.gripper = float(self.gripper_hold)
        cmd.mode = 4
        self.pub.publish(cmd)


def main():
    rclpy.init()
    node = CartTeleop()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
